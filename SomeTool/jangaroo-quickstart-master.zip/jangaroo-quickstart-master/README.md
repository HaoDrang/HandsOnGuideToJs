my-joo
======

A 'hello world' project for getting acquainted with the modular Jangaroo [Maven Build Process](https://github.com/CoreMedia/jangaroo-tools/wiki/Maven-Build-Process).